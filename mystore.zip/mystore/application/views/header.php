<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="<?= base_url("css/bootstrap.css")?>">
	<link rel="stylesheet" type="text/css" href="<?= base_url("css/main.css")?>">
	<link rel="stylesheet" type="text/css" href="<?= base_url("css/product.css")?>">
	<link rel="stylesheet" type="text/css" href="<?= base_url("css/success.css")?>">
	<link rel="stylesheet" type="text/css" href="<?= base_url("css/admin.css")?>">
	<script type="text/javascript" src="<?= base_url("js/jquery.js")?>"></script>
	<script type="text/javascript" src="<?= base_url("js/bootstrap.js")?>"></script>
</head>
<body>
	<div class="container">
