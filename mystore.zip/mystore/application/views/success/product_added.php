<div class="main">

	<div class="success bg-success">
		
		<h2>
			Product added successfully !
		</h2>

	</div>
	
</div>