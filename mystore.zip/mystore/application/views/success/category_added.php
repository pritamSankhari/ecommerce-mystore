<div class="main">

	<div class="success bg-success">
		
		<h2>
			Category added successfully !
		</h2>

	</div>
	
</div>