<div class="main">

	<div class="success bg-success">
		
		<h2>
			Product deleted successfully !
		</h2>

	</div>
	
</div>