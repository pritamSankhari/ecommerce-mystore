<div class="main">

	<div class="success bg-success">
		
		<h2>
			Order placed successfully !
		</h2>

	</div>
	
</div>