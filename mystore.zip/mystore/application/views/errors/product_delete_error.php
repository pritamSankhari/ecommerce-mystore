<div>
	<h2>Failed to upload product image!</h2>
</div>