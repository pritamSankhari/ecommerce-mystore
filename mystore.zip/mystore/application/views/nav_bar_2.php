<nav class="nav-bar-2">
	<a href="<?= site_url('main') ?>">Go to Home page</a>
	<a href="<?= site_url('admin') ?>">Go to Admin page</a>	
</nav>
