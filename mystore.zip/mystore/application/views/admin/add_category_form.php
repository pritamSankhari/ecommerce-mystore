<form method="post" action="<?= site_url('category/add') ?>">
	<div class="form-group">
		<input class="form-control" type="text" name="cat_name" placeholder="Category name">	
	</div>
	<input class="btn btn-warning" type="submit" name="add" value="Add">
	
</form>